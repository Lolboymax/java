import java.util.Scanner;

public class VersionComparator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first version string (e.g., 15.10.10): ");
        String v1 = scanner.nextLine();

        System.out.print("Enter second version string (e.g., 14.20.50): ");
        String v2 = scanner.nextLine();

        String[] parts1 = v1.split("\\.");
        String[] parts2 = v2.split("\\.");

        int len = Math.min(parts1.length, parts2.length);
        boolean compared = false;

        for (int i = 0; i < len; i++) {
            int num1 = Integer.parseInt(parts1[i]);
            int num2 = Integer.parseInt(parts2[i]);

            if (num1 > num2) {
                System.out.println(v1 + " is greater than " + v2);
                compared = true;
                break;
            } else if (num1 < num2) {
                System.out.println(v2 + " is greater than " + v1);
                compared = true;
                break;
            }
        }

        if (!compared) {
            if (parts1.length > parts2.length) {
                System.out.println(v1 + " is greater than " + v2);
            } else if (parts1.length < parts2.length) {
                System.out.println(v2 + " is greater than " + v1);
            } else {
                System.out.println(v1 + " is equal to " + v2);
            }
        }

        scanner.close();
    }
}
