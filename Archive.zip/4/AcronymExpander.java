import java.util.Scanner;

public class AcronymExpander {
    public static void main(String[] args) {
        String[][] acronyms = {
            {"JVM", "Java Virtual Machine"},
            {"API", "Application Programming Interface"},
            {"OOP", "Object Oriented Programming"},
            {"IDE", "Integrated Development Environment"},
            {"CPU", "Central Processing Unit"}
        };

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an acronym: ");
        String input = scanner.nextLine().toUpperCase();

        boolean found = false;
        for (String[] pair : acronyms) {
            if (pair[0].equals(input)) {
                System.out.println(input + ": " + pair[1]);
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Acronym not found.");
        }

        scanner.close();
    }
}
