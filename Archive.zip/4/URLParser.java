import java.net.URL;
import java.util.Scanner;

public class URLParser {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a URL: ");
        String input = scanner.nextLine();

        try {
            URL url = new URL(input);

            System.out.println("Protocol: " + url.getProtocol());
            System.out.println("Domain: " + url.getHost());
            System.out.println("Path: " + url.getPath());
            System.out.println("Query: " + url.getQuery());

            if (url.getQuery() != null) {
                String[] params = url.getQuery().split("&");
                System.out.println("Query Parameters:");
                for (String param : params) {
                    System.out.println(" - " + param);
                }
            }
        } catch (Exception e) {
            System.out.println("Invalid URL.");
        }

        scanner.close();
    }
}
