import java.util.Scanner;

public class LetterFrequency {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine().toLowerCase();

        int[] counts = new int[26];

        for (char c : input.toCharArray()) {
            if (c >= 'a' && c <= 'z') {
                counts[c - 'a']++;
            }
        }

        for (int i = 0; i < 26; i++) {
            if (counts[i] > 0) {
                System.out.println((char) ('a' + i) + ": " + counts[i]);
            }
        }

        scanner.close();
    }
}
