public class StringMethodsDemo {
    public static void main(String[] args) {
        String s1 = "Welcome to Java";
        String s2 = s1;
        String s3 = new String("Welcome to Java");
        String s4 = s1.intern();

        System.out.println("s1 == s2: " + (s1 == s2)); // true
        System.out.println("s1 == s3: " + (s1 == s3)); // false
        System.out.println("s1 == s4: " + (s1 == s4)); // true

        System.out.println("s1.equals(s3): " + s1.equals(s3)); // true

        System.out.println("s1 length: " + s1.length());
        System.out.println("s1 uppercase: " + s1.toUpperCase());
        System.out.println("s1 lowercase: " + s1.toLowerCase());
        System.out.println("s1 contains 'Java': " + s1.contains("Java"));
        System.out.println("s1 starts with 'Welcome': " + s1.startsWith("Welcome"));
        System.out.println("s1 ends with 'Java': " + s1.endsWith("Java"));
        System.out.println("s1 substring(0,7): " + s1.substring(0,7));
        System.out.println("s1 replace 'Java' with 'World': " + s1.replace("Java", "World"));
    }
}
