import java.util.Random;

public class ArrayElementOccurrences {
    public static void main(String[] args) {
        Random random = new Random();
        int n = 10;
        int[] A = new int[n];
        int[] B = new int[n];

        for (int i = 0; i < n; i++) {
            A[i] = random.nextInt(20); // 0-19
            B[i] = random.nextInt(20);
        }

        System.out.print("Array A: ");
        for (int num : A) {
            System.out.print(num + " ");
        }
        System.out.println();

        System.out.print("Array B: ");
        for (int num : B) {
            System.out.print(num + " ");
        }
        System.out.println();

        for (int i = 0; i < n; i++) {
            int count = 0;
            for (int j = 0; j < n; j++) {
                if (A[j] == B[i]) {
                    count++;
                }
            }
            System.out.println("Element " + B[i] + " occurs " + count + " times in A");
        }
    }
}
