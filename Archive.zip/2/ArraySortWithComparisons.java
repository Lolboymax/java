import java.util.Random;

public class ArraySortWithComparisons {
    public static void main(String[] args) {
        Random random = new Random();
        int size = 10; // example size
        int[] arr = new int[size];
        char[] charArr = new char[size];

        for (int i = 0; i < size; i++) {
            arr[i] = random.nextInt(100); // 0 to 99
            charArr[i] = (char) ('0' + (arr[i] % 10)); // last digit as char
        }

        int comparisons = bubbleSortWithCount(arr);

        System.out.println("Sorted array with index positions:");
        for (int i = 0; i < size; i++) {
            System.out.println("Index " + i + ": " + arr[i]);
        }

        System.out.println("Number of comparisons during sorting: " + comparisons);
    }

    private static int bubbleSortWithCount(int[] arr) {
        int n = arr.length;
        int count = 0;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                count++;
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        return count;
    }
}
