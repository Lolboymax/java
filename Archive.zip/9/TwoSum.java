import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;

public class TwoSum {

    public static int[] findTwoSumIndices(int[] nums, int target) {
        Map<Integer, Integer> numMap = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (numMap.containsKey(complement)) {
                return new int[] { numMap.get(complement), i };
            }
            numMap.put(nums[i], i);
        }
        return new int[] {}; // Return empty array if no solution found
    }

    public static void main(String[] args) {
        int[] numbers = {2, 7, 11, 15};
        int targetSum = 9;
        int[] result = findTwoSumIndices(numbers, targetSum);

        if (result.length == 2) {
            System.out.println("Input array: " + Arrays.toString(numbers));
            System.out.println("Target sum: " + targetSum);
            System.out.println("Indices found: " + result[0] + ", " + result[1]);
            System.out.println("Numbers: " + numbers[result[0]] + ", " + numbers[result[1]]);
        } else {
            System.out.println("No two numbers found that add up to the target sum " + targetSum);
        }

        int[] numbers2 = {3, 2, 4};
        int targetSum2 = 6;
        int[] result2 = findTwoSumIndices(numbers2, targetSum2);
         if (result2.length == 2) {
            System.out.println("\nInput array: " + Arrays.toString(numbers2));
            System.out.println("Target sum: " + targetSum2);
            System.out.println("Indices found: " + result2[0] + ", " + result2[1]);
            System.out.println("Numbers: " + numbers2[result2[0]] + ", " + numbers2[result2[1]]);
        } else {
            System.out.println("No two numbers found that add up to the target sum " + targetSum2);
        }
    }
}
