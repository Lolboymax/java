public class VowelConsonantCounter {

    public static void countVowelsConsonants(String word) {
        int vowels = 0;
        int consonants = 0;
        String lowerCaseWord = word.toLowerCase(); // Case-insensitive counting

        for (int i = 0; i < lowerCaseWord.length(); i++) {
            char ch = lowerCaseWord.charAt(i);

            if (ch >= 'a' && ch <= 'z') { // Check if it's a letter
                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                    vowels++;
                } else {
                    consonants++;
                }
            }
            // Non-alphabetic characters are ignored
        }

        System.out.println("Word: " + word);
        System.out.println("Vowels: " + vowels);
        System.out.println("Consonants: " + consonants);
    }

    public static void main(String[] args) {
        String word1 = "Programming";
        String word2 = "AEIOU";
        String word3 = "Rhythm";
        String word4 = "Hello World 123"; // Includes space and numbers

        countVowelsConsonants(word1);
        System.out.println();
        countVowelsConsonants(word2);
        System.out.println();
        countVowelsConsonants(word3);
         System.out.println();
        countVowelsConsonants(word4);
    }
}
