import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BasicExceptionHandling {

    // Method that might throw a checked exception
    public static void readFile(String fileName) throws IOException {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(fileName);
            System.out.println("Successfully opened file: " + fileName);
            // Simulate reading or processing the file
            int content;
            while ((content = fis.read()) != -1) {
                // Process content (not shown for simplicity)
            }
            System.out.println("Finished processing file.");
        } finally {
            // Ensure the file stream is closed even if an exception occurs
            if (fis != null) {
                try {
                    fis.close();
                    System.out.println("File stream closed.");
                } catch (IOException e) {
                    System.err.println("Error closing file stream: " + e.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) {

        // 1. Handling ArithmeticException (Unchecked)
        try {
            System.out.println("--- Attempting division by zero ---");
            int result = 10 / 0;
            System.out.println("Result (should not be reached): " + result);
        } catch (ArithmeticException e) {
            System.err.println("Caught ArithmeticException: " + e.getMessage());
        }

        // 2. Handling ArrayIndexOutOfBoundsException (Unchecked)
        try {
            System.out.println("\n--- Attempting to access invalid array index ---");
            int[] numbers = {1, 2, 3};
            System.out.println("Accessing index 5: " + numbers[5]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("Caught ArrayIndexOutOfBoundsException: " + e.getMessage());
        }

        // 3. Handling FileNotFoundException (Checked) using try-catch
        System.out.println("\n--- Attempting to read a non-existent file ---");
        try {
            readFile("non_existent_file.txt");
        } catch (FileNotFoundException e) {
            System.err.println("Caught FileNotFoundException: " + e.getMessage());
        } catch (IOException e) {
            // Catching broader IOExceptions that might occur during read/close
            System.err.println("Caught general IOException: " + e.getMessage());
        }

         // 4. Example with try-catch-finally where no exception occurs initially
         System.out.println("\n--- Example with finally block (no initial exception) ---");
         try {
             System.out.println("Inside try block.");
             // Create a dummy file to test successful read
             try (java.io.PrintWriter writer = new java.io.PrintWriter("AlgorithmExamples/temp_file.txt")) {
                 writer.println("Hello");
             } catch (FileNotFoundException fnf) {
                 System.err.println("Could not create temp file: " + fnf.getMessage());
             }
             readFile("AlgorithmExamples/temp_file.txt");
         } catch (IOException e) {
             System.err.println("Caught IOException in finally example: " + e.getMessage());
         } finally {
             System.out.println("This finally block always executes.");
             // Clean up the dummy file
             new java.io.File("AlgorithmExamples/temp_file.txt").delete();
         }

        System.out.println("\n--- Program finished ---");
    }
}
