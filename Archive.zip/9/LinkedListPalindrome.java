import java.util.Stack;

public class LinkedListPalindrome {

    static class Node {
        int data;
        Node next;

        Node(int d) {
            data = d;
            next = null;
        }
    }

    Node head; // Head of list

    // Function to check if linked list is palindrome
    boolean isPalindrome(Node head) {
        if (head == null || head.next == null) {
            return true; // An empty list or single node list is a palindrome
        }

        Node slow = head;
        Node fast = head;
        Stack<Integer> stack = new Stack<>();

        // Push the first half elements onto the stack
        while (fast != null && fast.next != null) {
            stack.push(slow.data);
            slow = slow.next;
            fast = fast.next.next;
        }

        // If the list has an odd number of elements, skip the middle element
        if (fast != null) {
            slow = slow.next;
        }

        // Compare the second half with the elements popped from the stack
        while (slow != null) {
            int top = stack.pop();
            if (top != slow.data) {
                return false; // Not a palindrome
            }
            slow = slow.next;
        }

        return true; // It's a palindrome
    }

    // Utility function to print the linked list
    void printList(Node node) {
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedListPalindrome list1 = new LinkedListPalindrome();
        list1.head = new Node(1);
        list1.head.next = new Node(2);
        list1.head.next.next = new Node(3);
        list1.head.next.next.next = new Node(2);
        list1.head.next.next.next.next = new Node(1);

        System.out.print("List 1: ");
        list1.printList(list1.head);
        System.out.println("Is Palindrome? " + list1.isPalindrome(list1.head)); // Should be true

        LinkedListPalindrome list2 = new LinkedListPalindrome();
        list2.head = new Node(1);
        list2.head.next = new Node(2);
        list2.head.next.next = new Node(3);
        list2.head.next.next.next = new Node(4);
        list2.head.next.next.next.next = new Node(5);

        System.out.print("List 2: ");
        list2.printList(list2.head);
        System.out.println("Is Palindrome? " + list2.isPalindrome(list2.head)); // Should be false

         LinkedListPalindrome list3 = new LinkedListPalindrome();
        list3.head = new Node(1);
        list3.head.next = new Node(2);
        list3.head.next.next = new Node(2);
        list3.head.next.next.next = new Node(1);

        System.out.print("List 3: ");
        list3.printList(list3.head);
        System.out.println("Is Palindrome? " + list3.isPalindrome(list3.head)); // Should be true
    }
}
