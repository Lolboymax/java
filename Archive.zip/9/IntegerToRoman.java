public class IntegerToRoman {

    private static final int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    private static final String[] symbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

    public static String intToRoman(int num) {
        if (num < 1 || num > 3999) {
            return "Input must be between 1 and 3999";
        }

        StringBuilder roman = new StringBuilder();
        int i = 0;
        while (num > 0) {
            while (num >= values[i]) {
                num -= values[i];
                roman.append(symbols[i]);
            }
            i++;
        }
        return roman.toString();
    }

    public static void main(String[] args) {
        int num1 = 3;
        int num2 = 58;
        int num3 = 1994;
        int num4 = 4000; // Example outside range

        System.out.println(num1 + " -> " + intToRoman(num1));
        System.out.println(num2 + " -> " + intToRoman(num2));
        System.out.println(num3 + " -> " + intToRoman(num3));
        System.out.println(num4 + " -> " + intToRoman(num4));
    }
}
