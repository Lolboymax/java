import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class TcpCapitalizerServer {

    private static final int PORT = 9090; // Port for the server to listen on

    public static void main(String[] args) {
        System.out.println("TCP Capitalizer Server started...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) { // Keep listening for new client connections
                try {
                    Socket clientSocket = serverSocket.accept(); // Wait for a client to connect
                    System.out.println("Client connected: " + clientSocket.getInetAddress());
                    handleClient(clientSocket); // Handle the client connection
                } catch (IOException e) {
                    System.err.println("Error accepting client connection: " + e.getMessage());
                    // Continue listening for other clients
                }
            }
        } catch (IOException e) {
            System.err.println("Could not start server on port " + PORT + ": " + e.getMessage());
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (
            BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true) // true for auto-flush
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Received from client: " + line);
                if (line.equalsIgnoreCase("exit")) {
                    System.out.println("Client requested exit.");
                    break; // Exit loop if client sends "exit"
                }
                String capitalizedLine = line.toUpperCase();
                writer.println(capitalizedLine); // Send capitalized line back to client
                System.out.println("Sent to client: " + capitalizedLine);
            }
        } catch (IOException e) {
            System.err.println("Error handling client " + clientSocket.getInetAddress() + ": " + e.getMessage());
        } finally {
            try {
                clientSocket.close(); // Ensure socket is closed
                System.out.println("Client disconnected: " + clientSocket.getInetAddress());
            } catch (IOException e) {
                System.err.println("Error closing client socket: " + e.getMessage());
            }
        }
    }
}
