import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UdpCapitalizerClient {

    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 9092; // Must match UDP server port
    private static final int BUFFER_SIZE = 1024;
    private static final int TIMEOUT_MS = 5000; // Timeout for receiving response (5 seconds)

    public static void main(String[] args) {
        System.out.println("UDP Capitalizer Client started...");
        System.out.println("Enter text to capitalize (or type 'exit' to quit):");

        try (DatagramSocket socket = new DatagramSocket(); // Use any available local port
             Scanner consoleScanner = new Scanner(System.in)) {

            InetAddress serverInetAddress = InetAddress.getByName(SERVER_ADDRESS);
            socket.setSoTimeout(TIMEOUT_MS); // Set timeout for receive()

            String userInput;
            while (true) {
                System.out.print("> ");
                userInput = consoleScanner.nextLine();

                byte[] sendBuffer = userInput.getBytes();

                // Send packet to server
                DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, serverInetAddress, SERVER_PORT);
                socket.send(sendPacket);

                if (userInput.equalsIgnoreCase("exit")) {
                    System.out.println("Exiting client.");
                    break;
                }

                // Prepare to receive response
                byte[] receiveBuffer = new byte[BUFFER_SIZE];
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);

                try {
                    socket.receive(receivePacket); // Wait for response (with timeout)
                    String serverResponse = new String(receivePacket.getData(), 0, receivePacket.getLength()).trim();
                    System.out.println("Server response: " + serverResponse);
                } catch (SocketTimeoutException e) {
                    System.err.println("No response received from server within timeout period.");
                    // Continue loop or break depending on desired behavior
                } catch (IOException e) {
                    System.err.println("Error receiving data from server: " + e.getMessage());
                    break; // Exit on receive error
                }
            }

        } catch (SocketException e) {
            System.err.println("Error creating or binding UDP socket: " + e.getMessage());
        } catch (UnknownHostException e) {
            System.err.println("Server address could not be resolved: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("I/O error sending data: " + e.getMessage());
        } catch (Exception e) {
             System.err.println("An unexpected error occurred: " + e.getMessage());
        } finally {
             System.out.println("Client finished.");
        }
    }
}
