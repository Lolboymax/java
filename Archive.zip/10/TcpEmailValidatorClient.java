import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class TcpEmailValidatorClient {

    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 9091; // Must match the validator server's port

    public static void main(String[] args) {
        System.out.println("TCP Email Validator Client started...");
        System.out.println("Enter email address to validate (or type 'exit' to quit):");

        try (
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            Scanner consoleScanner = new Scanner(System.in)
        ) {
            System.out.println("Connected to server: " + SERVER_ADDRESS + ":" + SERVER_PORT);
            String userInput;

            while (true) {
                System.out.print("> ");
                userInput = consoleScanner.nextLine();

                writer.println(userInput); // Send email to server

                if (userInput.equalsIgnoreCase("exit")) {
                    System.out.println("Exiting client.");
                    break;
                }

                String serverResponse = reader.readLine(); // Read response from server
                if (serverResponse != null) {
                    System.out.println("Server response: " + serverResponse);
                } else {
                    System.out.println("Server closed the connection unexpectedly.");
                    break;
                }
            }

        } catch (UnknownHostException e) {
            System.err.println("Server not found: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("I/O error connecting to server or during communication: " + e.getMessage());
        } catch (Exception e) {
             System.err.println("An unexpected error occurred: " + e.getMessage());
        } finally {
             System.out.println("Client finished.");
        }
    }
}
