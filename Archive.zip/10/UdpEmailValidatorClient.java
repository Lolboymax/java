import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UdpEmailValidatorClient {

    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 9093; // Must match UDP validator server port
    private static final int BUFFER_SIZE = 1024;
    private static final int TIMEOUT_MS = 5000; // Timeout for receiving response

    public static void main(String[] args) {
        System.out.println("UDP Email Validator Client started...");
        System.out.println("Enter email address to validate (or type 'exit' to quit):");

        try (DatagramSocket socket = new DatagramSocket();
             Scanner consoleScanner = new Scanner(System.in)) {

            InetAddress serverInetAddress = InetAddress.getByName(SERVER_ADDRESS);
            socket.setSoTimeout(TIMEOUT_MS);

            String userInput;
            while (true) {
                System.out.print("> ");
                userInput = consoleScanner.nextLine();

                byte[] sendBuffer = userInput.getBytes();

                // Send packet
                DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, serverInetAddress, SERVER_PORT);
                socket.send(sendPacket);

                if (userInput.equalsIgnoreCase("exit")) {
                    System.out.println("Exiting client.");
                    break;
                }

                // Receive response
                byte[] receiveBuffer = new byte[BUFFER_SIZE];
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);

                try {
                    socket.receive(receivePacket);
                    String serverResponse = new String(receivePacket.getData(), 0, receivePacket.getLength()).trim();
                    System.out.println("Server response: " + serverResponse);
                } catch (SocketTimeoutException e) {
                    System.err.println("No response received from server within timeout period.");
                } catch (IOException e) {
                    System.err.println("Error receiving data from server: " + e.getMessage());
                    break;
                }
            }

        } catch (SocketException e) {
            System.err.println("Error creating or binding UDP socket: " + e.getMessage());
        } catch (UnknownHostException e) {
            System.err.println("Server address could not be resolved: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("I/O error sending data: " + e.getMessage());
        } catch (Exception e) {
             System.err.println("An unexpected error occurred: " + e.getMessage());
        } finally {
             System.out.println("Client finished.");
        }
    }
}
