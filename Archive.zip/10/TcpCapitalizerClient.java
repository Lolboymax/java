import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class TcpCapitalizerClient {

    private static final String SERVER_ADDRESS = "localhost"; // Or server IP address
    private static final int SERVER_PORT = 9090; // Must match the server's port

    public static void main(String[] args) {
        System.out.println("TCP Capitalizer Client started...");
        System.out.println("Enter text to capitalize (or type 'exit' to quit):");

        try (
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            Scanner consoleScanner = new Scanner(System.in)
        ) {
            System.out.println("Connected to server: " + SERVER_ADDRESS + ":" + SERVER_PORT);
            String userInput;

            while (true) {
                System.out.print("> ");
                userInput = consoleScanner.nextLine();

                writer.println(userInput); // Send user input to server

                if (userInput.equalsIgnoreCase("exit")) {
                    System.out.println("Exiting client.");
                    break; // Exit loop if user types "exit"
                }

                String serverResponse = reader.readLine(); // Read response from server
                if (serverResponse != null) {
                    System.out.println("Server response: " + serverResponse);
                } else {
                    System.out.println("Server closed the connection unexpectedly.");
                    break;
                }
            }

        } catch (UnknownHostException e) {
            System.err.println("Server not found: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("I/O error connecting to server or during communication: " + e.getMessage());
        } catch (Exception e) {
             System.err.println("An unexpected error occurred: " + e.getMessage());
        } finally {
             System.out.println("Client finished.");
        }
    }
}
