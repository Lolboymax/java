import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class UdpCapitalizerServer {

    private static final int PORT = 9092; // Port for UDP server
    private static final int BUFFER_SIZE = 1024;

    public static void main(String[] args) {
        System.out.println("UDP Capitalizer Server started...");
        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            byte[] receiveBuffer = new byte[BUFFER_SIZE];

            while (true) { // Keep listening for datagrams
                try {
                    // Receive packet
                    DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                    socket.receive(receivePacket); // Blocks until a packet is received

                    InetAddress clientAddress = receivePacket.getAddress();
                    int clientPort = receivePacket.getPort();
                    String receivedData = new String(receivePacket.getData(), 0, receivePacket.getLength()).trim();

                    System.out.println("Received from " + clientAddress + ":" + clientPort + ": " + receivedData);

                    if (receivedData.equalsIgnoreCase("exit")) {
                        System.out.println("Client " + clientAddress + ":" + clientPort + " requested exit.");
                        // Optionally send a confirmation back, or just continue
                        continue;
                    }

                    // Process data (capitalize)
                    String capitalizedData = receivedData.toUpperCase();
                    byte[] sendBuffer = capitalizedData.getBytes();

                    // Send response packet
                    DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, clientAddress, clientPort);
                    socket.send(sendPacket);
                    System.out.println("Sent to " + clientAddress + ":" + clientPort + ": " + capitalizedData);

                    // Clear buffer for next receive (optional but good practice)
                    receiveBuffer = new byte[BUFFER_SIZE];

                } catch (IOException e) {
                    System.err.println("I/O error during datagram handling: " + e.getMessage());
                    // Continue listening
                }
            }
        } catch (SocketException e) {
            System.err.println("Could not start UDP server on port " + PORT + ": " + e.getMessage());
        }
    }
}
