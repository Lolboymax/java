import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.regex.Pattern;

public class UdpEmailValidatorServer {

    private static final int PORT = 9093; // Different port for UDP validator
    private static final int BUFFER_SIZE = 1024;
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");

    public static void main(String[] args) {
        System.out.println("UDP Email Validator Server started...");
        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            byte[] receiveBuffer = new byte[BUFFER_SIZE];

            while (true) {
                try {
                    DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                    socket.receive(receivePacket);

                    InetAddress clientAddress = receivePacket.getAddress();
                    int clientPort = receivePacket.getPort();
                    String receivedData = new String(receivePacket.getData(), 0, receivePacket.getLength()).trim();

                    System.out.println("Received from " + clientAddress + ":" + clientPort + ": " + receivedData);

                     if (receivedData.equalsIgnoreCase("exit")) {
                        System.out.println("Client " + clientAddress + ":" + clientPort + " requested exit.");
                        continue;
                    }

                    // Validate email
                    boolean isValid = EMAIL_PATTERN.matcher(receivedData).matches();
                    String response = isValid ? "Valid" : "Invalid";
                    byte[] sendBuffer = response.getBytes();

                    // Send response
                    DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, clientAddress, clientPort);
                    socket.send(sendPacket);
                    System.out.println("Sent to " + clientAddress + ":" + clientPort + ": " + response);

                    receiveBuffer = new byte[BUFFER_SIZE]; // Clear buffer

                } catch (IOException e) {
                    System.err.println("I/O error during datagram handling: " + e.getMessage());
                }
            }
        } catch (SocketException e) {
            System.err.println("Could not start UDP server on port " + PORT + ": " + e.getMessage());
        }
    }
}
