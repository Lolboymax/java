import java.io.IOException;

public class ExceptionPropagation {

    // Method that throws a checked exception (IOException)
    void method1() throws IOException {
        System.out.println("Inside method1 - throws IOException");
        throw new IOException("Device error (Checked Exception)");
    }

    // Method that calls method1() and handles the checked exception
    void method2() {
        System.out.println("Inside method2 - calling method1");
        try {
            method1();
        } catch (IOException e) {
            System.out.println("Caught checked exception in method2: " + e.getMessage());
        }
        System.out.println("method2 finished");
    }

    // Method that calls method2()
    void method3() {
        System.out.println("Inside method3 - calling method2");
        method2(); // method2 handles the exception, so method3 doesn't need to declare/handle it
        System.out.println("method3 finished");
    }

    // Method that throws an unchecked exception (ArithmeticException)
    void methodA() {
        System.out.println("Inside methodA - throws ArithmeticException");
        int result = 10 / 0; // This will cause an ArithmeticException
        System.out.println("This won't be printed"); // To avoid unreachable code warning
    }

    // Method that calls methodA() but doesn't handle the unchecked exception
    void methodB() {
        System.out.println("Inside methodB - calling methodA");
        methodA(); // Unchecked exception propagates automatically
        System.out.println("methodB finished (won't be reached if exception occurs)");
    }

    // Method that calls methodB()
    void methodC() {
        System.out.println("Inside methodC - calling methodB");
        try {
            methodB();
        } catch (ArithmeticException e) {
            System.out.println("Caught unchecked exception in methodC: " + e.getMessage());
        }
        System.out.println("methodC finished");
    }


    public static void main(String[] args) {
        ExceptionPropagation obj = new ExceptionPropagation();

        System.out.println("--- Demonstrating Checked Exception Propagation (Handled) ---");
        obj.method3(); // Starts the chain for checked exception

        System.out.println("\n--- Demonstrating Unchecked Exception Propagation ---");
        obj.methodC(); // Starts the chain for unchecked exception
    }
}
