class InvalidMarkException extends Exception {
    public InvalidMarkException(String message) {
        super(message);
    }
}

class Student {
    private int mark;

    public void setMark(int mark) throws InvalidMarkException {
        if (mark < 0 || mark > 100) {
            throw new InvalidMarkException("Mark must be between 0 and 100.");
        }
        this.mark = mark;
    }

    public int getMark() {
        return mark;
    }
}

public class StudentWithCustomException {
    public static void main(String[] args) {
        Student student = new Student();
        try {
            student.setMark(105);
        } catch (InvalidMarkException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            student.setMark(85);
            System.out.println("Mark set to: " + student.getMark());
        } catch (InvalidMarkException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
