import java.io.IOException;
import java.io.FileNotFoundException;

public class OverloadingExceptionDemo {

    public void processData(String data) throws IOException {
        System.out.println("Processing String data: " + data);
        if (data.equals("error")) {
            throw new IOException("IO error processing string");
        }
    }

    public void processData(int data) throws FileNotFoundException {
        System.out.println("Processing int data: " + data);
        if (data < 0) {
            throw new FileNotFoundException("File not found for negative int");
        }
    }

    public void processData(double data) {
        System.out.println("Processing double data: " + data);
        if (data == 0.0) {
            throw new ArithmeticException("Cannot process zero double");
        }
    }

    public static void main(String[] args) {
        OverloadingExceptionDemo demo = new OverloadingExceptionDemo();

        System.out.println("--- Testing Overloaded Methods with Exceptions ---");

        try {
            System.out.println("\nCalling processData(String):");
            demo.processData("valid data");
            demo.processData("error");
        } catch (IOException e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }

        try {
            System.out.println("\nCalling processData(int):");
            demo.processData(100);
            demo.processData(-5);
        } catch (FileNotFoundException e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }

        try {
            System.out.println("\nCalling processData(double):");
            demo.processData(123.45);
            demo.processData(0.0);
        } catch (ArithmeticException e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }

        System.out.println("\n--- End of Demonstration ---");
    }
}
