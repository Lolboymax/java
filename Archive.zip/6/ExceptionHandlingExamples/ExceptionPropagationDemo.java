import java.io.IOException;

public class ExceptionPropagationDemo {

    void method3() throws IOException {
        throw new IOException("Checked exception occurred in method3");
    }

    void method2() throws IOException {
        method3();
        System.out.println("method2 completed");
    }

    void method1() {
        try {
            method2();
        } catch (IOException e) {
            System.out.println("Caught checked exception in method1: " + e.getMessage());
        }
        System.out.println("method1 completed after handling checked exception");
    }

    void uncheckedMethod3() {
        throw new ArithmeticException("Unchecked exception occurred in uncheckedMethod3");
    }

    void uncheckedMethod2() {
        uncheckedMethod3();
        System.out.println("uncheckedMethod2 completed");
    }

    void uncheckedMethod1() {
        try {
            uncheckedMethod2();
        } catch (ArithmeticException e) {
            System.out.println("Caught unchecked exception in uncheckedMethod1: " + e.getMessage());
        }
        System.out.println("uncheckedMethod1 completed after handling unchecked exception");
    }


    public static void main(String[] args) {
        ExceptionPropagationDemo demo = new ExceptionPropagationDemo();

        System.out.println("Demonstrating Checked Exception Propagation:");
        demo.method1();

        System.out.println("\nDemonstrating Unchecked Exception Propagation:");
        demo.uncheckedMethod1();

        System.out.println("\nDemonstrating Unchecked Exception Propagation without handling:");
        try {
             demo.uncheckedMethod2();
        } catch(ArithmeticException e) {
             System.out.println("Caught unchecked exception in main: " + e.getMessage());
        }
    }
}
