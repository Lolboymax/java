import java.io.IOException;
import java.io.FileNotFoundException;

class BaseClassUnchecked {
    void display() {
        System.out.println("BaseClassUnchecked: display() - potentially throws RuntimeException");
        if (System.currentTimeMillis() % 2 == 0) {
             throw new NullPointerException("Base Unchecked Exception");
        }
    }
}

class DerivedClassUnchecked extends BaseClassUnchecked {
    @Override
    void display() {
        System.out.println("DerivedClassUnchecked: display() - potentially throws different RuntimeException");
         if (System.currentTimeMillis() % 3 == 0) {
             throw new ArithmeticException("Derived Unchecked Exception");
         }
         super.display();
    }
}


class BaseClassChecked {
    void process() throws IOException {
        System.out.println("BaseClassChecked: process() - throws IOException");
        throw new IOException("Base Checked Exception");
    }
}


class DerivedClassCheckedSame extends BaseClassChecked {
     @Override
     void process() throws IOException {
         System.out.println("DerivedClassCheckedSame: process() - throws same IOException");
         throw new IOException("Derived Same Checked Exception");
     }
}


class DerivedClassCheckedSubclass extends BaseClassChecked {
     @Override
     void process() throws FileNotFoundException {
         System.out.println("DerivedClassCheckedSubclass: process() - throws subclass FileNotFoundException");
         throw new FileNotFoundException("Derived Subclass Checked Exception");
     }
}


class DerivedClassCheckedNone extends BaseClassChecked {
    @Override
    void process() {
        System.out.println("DerivedClassCheckedNone: process() - throws no checked exception");
    }
}


public class OverridingExceptionDemo {

    public static void main(String[] args) {

        System.out.println("--- Demonstrating Overriding with Unchecked Exceptions ---");
        BaseClassUnchecked baseUnchecked = new DerivedClassUnchecked();
        try {
            baseUnchecked.display();
            System.out.println("No unchecked exception occurred this time.");
        } catch (RuntimeException e) {
            System.out.println("Caught RuntimeException: " + e.getMessage());
        }

        System.out.println("\n--- Demonstrating Overriding with Checked Exceptions ---");

        BaseClassChecked baseChecked = new BaseClassChecked();
        try {
            System.out.println("\nCalling BaseClassChecked process():");
            baseChecked.process();
        } catch (IOException e) {
            System.out.println("Caught IOException from Base: " + e.getMessage());
        }

        BaseClassChecked derivedSame = new DerivedClassCheckedSame();
        try {
            System.out.println("\nCalling DerivedClassCheckedSame process():");
            derivedSame.process();
        } catch (IOException e) {
            System.out.println("Caught IOException from DerivedSame: " + e.getMessage());
        }

        BaseClassChecked derivedSubclass = new DerivedClassCheckedSubclass();
        try {
            System.out.println("\nCalling DerivedClassCheckedSubclass process():");
            derivedSubclass.process();
        } catch (IOException e) { // Catching IOException is still valid
            System.out.println("Caught IOException (actually subclass) from DerivedSubclass: " + e.getMessage());
        }

        BaseClassChecked derivedNone = new DerivedClassCheckedNone();
        try {
             System.out.println("\nCalling DerivedClassCheckedNone process():");
             derivedNone.process();
             System.out.println("DerivedClassCheckedNone executed without exception.");
        } catch (IOException e) {
             System.out.println("This should not be caught: " + e.getMessage());
        }

        System.out.println("\n--- End of Demonstration ---");
    }
}
