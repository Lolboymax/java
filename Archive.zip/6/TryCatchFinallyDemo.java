import java.io.FileInputStream;
import java.io.IOException;

public class TryCatchFinallyDemo {
    public static void main(String[] args) {
        tryWithoutCatch();
        tryWithoutFinally();
        tryWithCatchAndFinally();
        tryWithMultipleCatch();
        nestedTryCatchFinally();
        tryWithResources();
    }

    static void tryWithoutCatch() {
        System.out.println("\nTry without catch block:");
        try {
            int a = 5 / 0;
        } finally {
            System.out.println("Finally block executed");
        }
    }

    static void tryWithoutFinally() {
        System.out.println("\nTry without finally block:");
        try {
            int a = 5 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException");
        }
    }

    static void tryWithCatchAndFinally() {
        System.out.println("\nTry with catch and finally block:");
        try {
            int a = 5 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException");
        } finally {
            System.out.println("Finally block executed");
        }
    }

    static void tryWithMultipleCatch() {
        System.out.println("\nTry with multiple catch blocks:");
        try {
            int[] arr = new int[2];
            System.out.println(arr[5]);
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught ArrayIndexOutOfBoundsException");
        } catch (Exception e) {
            System.out.println("Caught general Exception");
        }
    }

    static void nestedTryCatchFinally() {
        System.out.println("\nNested try-catch-finally:");
        try {
            try {
                int a = 5 / 0;
            } catch (ArithmeticException e) {
                System.out.println("Inner catch: ArithmeticException");
            } finally {
                System.out.println("Inner finally");
            }
        } catch (Exception e) {
            System.out.println("Outer catch");
        } finally {
            System.out.println("Outer finally");
        }
    }

    static void tryWithResources() {
        System.out.println("\nTry with resources:");
        try (FileInputStream fis = new FileInputStream("nonexistent.txt")) {
            fis.read();
        } catch (IOException e) {
            System.out.println("Caught IOException: " + e.getMessage());
        }
    }
}
