import java.util.Scanner;

public class UncheckedExceptionDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter a number: ");
            int num = scanner.nextInt();

            int result = 100 / num; // may cause ArithmeticException
            System.out.println("Result: " + result);

            int[] arr = {1, 2, 3};
            System.out.print("Enter array index: ");
            int index = scanner.nextInt();

            System.out.println("Array element: " + arr[index]); // may cause ArrayIndexOutOfBoundsException

        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Invalid array index.");
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            scanner.close();
            System.out.println("Program finished.");
        }
    }
}
