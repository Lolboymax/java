import java.util.Scanner;

public class WindChillCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter temperature in Fahrenheit (<= 50°F): ");
        double temperature = scanner.nextDouble();

        System.out.print("Enter wind speed in mph (3 to 120): ");
        double windSpeed = scanner.nextDouble();

        if (temperature > 50) {
            System.out.println("Temperature must be less than or equal to 50°F.");
        } else if (windSpeed < 3 || windSpeed > 120) {
            System.out.println("Wind speed must be between 3 and 120 mph.");
        } else {
            double windChill = 35.74 + 0.6215 * temperature
                    + (0.4275 * temperature - 35.75) * Math.pow(windSpeed, 0.16);
            System.out.printf("The wind chill is: %.2f°F\n", windChill);
        }

        scanner.close();
    }
}
