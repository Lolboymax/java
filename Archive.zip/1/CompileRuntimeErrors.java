public class CompileRuntimeErrors {
    // Correct version
    public static void main(String[] args) {
        System.out.println("Hello, Error Testing!");
    }

    /*
    // (a) Delete semicolon - Compile-time error: ';' expected
    public static void main(String[] args) {
        System.out.println("Missing semicolon")
    }
    */

    /*
    // (b) Swap the words public, static, void, main - Compile-time error: Invalid method declaration
    static public main void(String[] args) {
        System.out.println("Swapped keywords");
    }
    */

    /*
    // (c) Omit the word public, static, void, main - Compile-time error: Invalid method declaration
    main(String[] args) {
        System.out.println("Omitted keywords");
    }
    */

    /*
    // (d) Remove array subscript around String - Compile-time error: ']' expected
    public static void main(String args) {
        System.out.println("Removed array subscript");
    }
    */

    /*
    // (e) Replace String with int or float - Compile-time error: incompatible types
    public static void main(int[] args) {
        System.out.println("Replaced String with int");
    }
    */

    /*
    // (f) Replace String[] with String... - This is valid syntax in Java (varargs), so it will compile and run
    public static void main(String... args) {
        System.out.println("Using varargs instead of array");
    }
    */
}
