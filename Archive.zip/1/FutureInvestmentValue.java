import java.util.Random;

public class FutureInvestmentValue {
    public static void main(String[] args) {
        Random random = new Random();

        long principal = 10000 + random.nextInt(90001); // 10,000 to 100,000
        double rate = 1.0 + (9.0 * random.nextDouble()); // 1.0% to 10.0%
        int years = 1 + random.nextInt(30); // 1 to 30 years

        double amount = principal * Math.pow(1 + rate / 100, years);

        System.out.printf("Principal: Rs %d\n", principal);
        System.out.printf("Annual Interest Rate: %.2f%%\n", rate);
        System.out.printf("Years: %d\n", years);
        System.out.printf("Future Value: Rs %.2f\n", amount);
    }
}
