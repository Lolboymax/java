public class GreetFriend {
    public static void main(String[] args) {
        System.out.println("Hello, my friend!");
    }
}
