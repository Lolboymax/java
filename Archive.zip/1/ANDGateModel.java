public class ANDGateModel {
    public static void main(String[] args) {
        double bias = -1.0;
        double w0 = 1.0;
        double w1 = 1.0;

        int[][] inputs = {
            {0, 0},
            {0, 1},
            {1, 0},
            {1, 1}
        };

        for (int[] input : inputs) {
            int x1 = input[0];
            int x2 = input[1];
            double y = bias + w0 * x1 + w1 * x2;
            int output = (y > 0.5) ? 1 : 0;
            System.out.println("Input: (" + x1 + ", " + x2 + ") => Output: " + output);
        }
    }
}
