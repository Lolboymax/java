import java.util.Scanner;

public class DigitPositions {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();

        String numStr = Integer.toString(number);
        for (int i = 0; i < numStr.length(); i++) {
            System.out.println("Position " + (i + 1) + ": " + numStr.charAt(i));
        }

        scanner.close();
    }
}
