package com.example;

import java.sql.*;

public class StudentJdbcDemo {

    // H2 In-Memory Database URL. DB_CLOSE_DELAY=-1 keeps the DB open as long as the VM lives.
    private static final String DB_URL = "jdbc:h2:mem:studentdb;DB_CLOSE_DELAY=-1";
    private static final String DB_USER = "sa"; // Default H2 user
    private static final String DB_PASSWORD = ""; // Default H2 password

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        try {
            // 1. Load the driver (Optional for JDBC 4.0+, but good practice to know)
            // Class.forName("org.h2.Driver"); // Not strictly needed with modern JDBC/Maven

            // 2. Create a Connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Connected successfully.");

            // 3. Create table using Statement
            stmt = conn.createStatement();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS students (" +
                                    " id VARCHAR(10) PRIMARY KEY, " +
                                    " name VARCHAR(255), " +
                                    " gpa DECIMAL(3, 2)" + // e.g., 3.45
                                    ")";
            System.out.println("Executing: " + createTableSQL);
            stmt.executeUpdate(createTableSQL);
            System.out.println("Table 'students' created or already exists.");
            stmt.close(); // Close statement after use

            // --- Demonstrate Operations ---

            // 4a. Insert using PreparedStatement (executeUpdate)
            System.out.println("\n--- Inserting Students ---");
            addStudent(conn, "S101", "Alice", 3.85);
            addStudent(conn, "S102", "Bob", 3.50);
            addStudent(conn, "S103", "Charlie", 3.92);

            // 4b. Select All using Statement (executeQuery)
            System.out.println("\n--- All Students ---");
            getAllStudents(conn);

            // 4c. Select Specific using PreparedStatement (executeQuery)
            System.out.println("\n--- Get Student S102 ---");
            getStudentById(conn, "S102");

            // 4d. Update using PreparedStatement (executeUpdate)
            System.out.println("\n--- Updating Bob's GPA ---");
            updateStudentGpa(conn, "S102", 3.65);
            getStudentById(conn, "S102"); // Show updated record

            // 4e. Delete using PreparedStatement (executeUpdate)
            System.out.println("\n--- Deleting Alice ---");
            deleteStudent(conn, "S101");

            // 4f. Select All again
            System.out.println("\n--- All Students After Delete ---");
            getAllStudents(conn);


        } catch (SQLException se) {
            System.err.println("Database Error:");
            se.printStackTrace();
        } catch (Exception e) {
            System.err.println("General Error:");
            e.printStackTrace();
        } finally {
            // 7. Close resources (Connection)
            // Statements and ResultSets used within methods are closed via try-with-resources
            try {
                if (conn != null) {
                    conn.close();
                    System.out.println("\nDatabase connection closed.");
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println("Program finished.");
    }

    // --- Helper Methods for DB Operations ---

    public static void addStudent(Connection conn, String id, String name, double gpa) throws SQLException {
        String sql = "INSERT INTO students (id, name, gpa) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            pstmt.setString(2, name);
            pstmt.setDouble(3, gpa);
            int rowsAffected = pstmt.executeUpdate(); // Use executeUpdate for INSERT
            System.out.println("Inserted " + name + ". Rows affected: " + rowsAffected);
        }
    }

    public static void getAllStudents(Connection conn) throws SQLException {
        String sql = "SELECT id, name, gpa FROM students";
        // Using try-with-resources for Statement and ResultSet
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) { // Use executeQuery for SELECT

            // 6. Retrieve results using ResultSet
            boolean found = false;
            while (rs.next()) {
                found = true;
                String id = rs.getString("id");
                String name = rs.getString("name");
                double gpa = rs.getDouble("gpa");
                System.out.println("ID: " + id + ", Name: " + name + ", GPA: " + gpa);
            }
            if (!found) {
                System.out.println("No students found in the table.");
            }
        } // Resources rs and stmt are automatically closed here
    }

     public static void getStudentById(Connection conn, String studentId) throws SQLException {
        String sql = "SELECT id, name, gpa FROM students WHERE id = ?";
        // Using try-with-resources for PreparedStatement and ResultSet
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, studentId);
            try (ResultSet rs = pstmt.executeQuery()) { // Use executeQuery for SELECT
                if (rs.next()) {
                    String id = rs.getString("id");
                    String name = rs.getString("name");
                    double gpa = rs.getDouble("gpa");
                    System.out.println("Found - ID: " + id + ", Name: " + name + ", GPA: " + gpa);
                } else {
                    System.out.println("Student with ID " + studentId + " not found.");
                }
            } // ResultSet rs is automatically closed here
        } // PreparedStatement pstmt is automatically closed here
    }

    public static void updateStudentGpa(Connection conn, String id, double newGpa) throws SQLException {
        String sql = "UPDATE students SET gpa = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, newGpa);
            pstmt.setString(2, id);
            int rowsAffected = pstmt.executeUpdate(); // Use executeUpdate for UPDATE
            System.out.println("Updated GPA for ID " + id + ". Rows affected: " + rowsAffected);
             if (rowsAffected == 0) {
                 System.out.println("Warning: Student ID " + id + " not found for update.");
             }
        }
    }

    public static void deleteStudent(Connection conn, String id) throws SQLException {
        String sql = "DELETE FROM students WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            int rowsAffected = pstmt.executeUpdate(); // Use executeUpdate for DELETE
            System.out.println("Deleted student with ID " + id + ". Rows affected: " + rowsAffected);
             if (rowsAffected == 0) {
                 System.out.println("Warning: Student ID " + id + " not found for deletion.");
             }
        }
    }
}
