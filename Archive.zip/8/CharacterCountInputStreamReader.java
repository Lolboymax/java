import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

public class CharacterCountInputStreamReader {

    private static final char CHAR_TO_COUNT = 'a';

    public static void main(String[] args) {
        String sourceFile = "IOExamples/sample.txt";
        int charCount = 0;

        System.out.println("Counting character '" + CHAR_TO_COUNT + "' in file: " + sourceFile + " using InputStreamReader...");

        try (FileInputStream fis = new FileInputStream(sourceFile);
             Reader reader = new InputStreamReader(fis)) { // Using default charset

            int charRead;
            while ((charRead = reader.read()) != -1) {
                char currentChar = (char) charRead;
                if (Character.toLowerCase(currentChar) == CHAR_TO_COUNT) {
                    charCount++;
                }
            }

            System.out.println("\n--- Results ---");
            System.out.println("Total occurrences of character '" + CHAR_TO_COUNT + "': " + charCount);

        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        System.out.println("\nOperation complete.");
    }
}
