import java.io.*;

public class FileCopyPerformance {

    private static final char CHAR_TO_COUNT = 'a';
    private static final int ENCRYPTION_SHIFT = 3;

    public static void main(String[] args) {
        String sourceFile = "IOExamples/sample.txt";
        String byteDestFile = "IOExamples/sample_byte_copy_encrypted.txt";
        String charDestFile = "IOExamples/sample_char_copy_encrypted.txt";

        System.out.println("Starting file copy operations...");

        // --- Byte Stream Copy ---
        long startTimeByte = System.nanoTime();
        int countByte = copyUsingByteStreams(sourceFile, byteDestFile);
        long endTimeByte = System.nanoTime();
        long durationByte = (endTimeByte - startTimeByte) / 1_000_000; // milliseconds

        if (countByte != -1) {
            System.out.println("\n--- Byte Stream Results ---");
            System.out.println("File copied to: " + byteDestFile);
            System.out.println("Character '" + CHAR_TO_COUNT + "' count: " + countByte);
            System.out.println("Time taken: " + durationByte + " ms");
        } else {
             System.out.println("\nByte Stream copy failed.");
        }


        // --- Character Stream Copy ---
        long startTimeChar = System.nanoTime();
        int countChar = copyUsingCharacterStreams(sourceFile, charDestFile);
        long endTimeChar = System.nanoTime();
        long durationChar = (endTimeChar - startTimeChar) / 1_000_000; // milliseconds

         if (countChar != -1) {
            System.out.println("\n--- Character Stream Results ---");
            System.out.println("File copied to: " + charDestFile);
            System.out.println("Character '" + CHAR_TO_COUNT + "' count: " + countChar);
            System.out.println("Time taken: " + durationChar + " ms");
        } else {
             System.out.println("\nCharacter Stream copy failed.");
        }

        System.out.println("\n--- Performance Comparison ---");
        if (countByte != -1 && countChar != -1) {
            if (durationByte < durationChar) {
                System.out.println("Byte stream was faster.");
            } else if (durationChar < durationByte) {
                System.out.println("Character stream was faster.");
            } else {
                System.out.println("Both streams took similar time.");
            }
        } else {
            System.out.println("Comparison not possible due to copy failure.");
        }
         System.out.println("\nOperations complete.");
    }

    private static int copyUsingByteStreams(String sourcePath, String destPath) {
        int charCount = 0;
        try (FileInputStream fis = new FileInputStream(sourcePath);
             FileOutputStream fos = new FileOutputStream(destPath)) {

            int byteRead;
            while ((byteRead = fis.read()) != -1) {
                char originalChar = (char) byteRead;
                if (Character.toLowerCase(originalChar) == CHAR_TO_COUNT) {
                    charCount++;
                }
                int encryptedByte = encryptByte(byteRead);
                fos.write(encryptedByte);
            }
            return charCount;
        } catch (IOException e) {
            System.err.println("Error during byte stream copy: " + e.getMessage());
            return -1; // Indicate error
        }
    }

    private static int copyUsingCharacterStreams(String sourcePath, String destPath) {
         int charCount = 0;
        try (FileReader reader = new FileReader(sourcePath);
             FileWriter writer = new FileWriter(destPath)) {

            int charRead;
            while ((charRead = reader.read()) != -1) {
                 char originalChar = (char) charRead;
                if (Character.toLowerCase(originalChar) == CHAR_TO_COUNT) {
                    charCount++;
                }
                char encryptedChar = encryptChar(originalChar);
                writer.write(encryptedChar);
            }
             return charCount;
        } catch (IOException e) {
            System.err.println("Error during character stream copy: " + e.getMessage());
            return -1; // Indicate error
        }
    }

    // Simple Caesar cipher encryption for bytes
    private static int encryptByte(int b) {
        char c = (char) b;
        if (Character.isLetter(c)) {
            char base = Character.isUpperCase(c) ? 'A' : 'a';
            return base + (c - base + ENCRYPTION_SHIFT) % 26;
        }
        return b; // Return non-letters unchanged
    }

     // Simple Caesar cipher encryption for characters
    private static char encryptChar(char c) {
        if (Character.isLetter(c)) {
            char base = Character.isUpperCase(c) ? 'A' : 'a';
            return (char) (base + (c - base + ENCRYPTION_SHIFT) % 26);
        }
        return c; // Return non-letters unchanged
    }
}
