import java.io.*;

public class BufferedFileCopyPerformance {

    private static final String WORD_TO_COUNT = "Java";
    private static final int ENCRYPTION_SHIFT = 3;
    private static final int BUFFER_SIZE = 8192; // Common buffer size

    public static void main(String[] args) {
        String sourceFile = "IOExamples/sample.txt";
        String byteDestFile = "IOExamples/sample_buffered_byte_copy_encrypted.txt";
        String charDestFile = "IOExamples/sample_buffered_char_copy_encrypted.txt";

        System.out.println("Starting buffered file copy operations...");

        // --- Buffered Byte Stream Copy ---
        long startTimeByte = System.nanoTime();
        int countByte = copyUsingBufferedByteStreams(sourceFile, byteDestFile);
        long endTimeByte = System.nanoTime();
        long durationByte = (endTimeByte - startTimeByte) / 1_000_000; // milliseconds

        if (countByte != -1) {
            System.out.println("\n--- Buffered Byte Stream Results ---");
            System.out.println("File copied to: " + byteDestFile);
            System.out.println("Word '" + WORD_TO_COUNT + "' count: " + countByte);
            System.out.println("Time taken: " + durationByte + " ms");
        } else {
             System.out.println("\nBuffered Byte Stream copy failed.");
        }

        // --- Buffered Character Stream Copy ---
        long startTimeChar = System.nanoTime();
        int countChar = copyUsingBufferedCharacterStreams(sourceFile, charDestFile);
        long endTimeChar = System.nanoTime();
        long durationChar = (endTimeChar - startTimeChar) / 1_000_000; // milliseconds

         if (countChar != -1) {
            System.out.println("\n--- Buffered Character Stream Results ---");
            System.out.println("File copied to: " + charDestFile);
            System.out.println("Word '" + WORD_TO_COUNT + "' count: " + countChar);
            System.out.println("Time taken: " + durationChar + " ms");
        } else {
             System.out.println("\nBuffered Character Stream copy failed.");
        }

        System.out.println("\n--- Performance Comparison (Buffered) ---");
         if (countByte != -1 && countChar != -1) {
            if (durationByte < durationChar) {
                System.out.println("Buffered byte stream was faster.");
            } else if (durationChar < durationByte) {
                System.out.println("Buffered character stream was faster.");
            } else {
                System.out.println("Both buffered streams took similar time.");
            }
            System.out.println("(Note: Buffered streams are generally significantly faster than non-buffered streams for file I/O due to reduced disk access frequency.)");
        } else {
            System.out.println("Comparison not possible due to copy failure.");
        }
         System.out.println("\nOperations complete.");
    }

    private static int copyUsingBufferedByteStreams(String sourcePath, String destPath) {
        int wordCount = 0;
        StringBuilder currentWord = new StringBuilder(); // To build words across buffer reads

        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(sourcePath), BUFFER_SIZE);
             BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(destPath), BUFFER_SIZE)) {

            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = bis.read(buffer)) != -1) {
                byte[] encryptedBuffer = new byte[bytesRead];
                for (int i = 0; i < bytesRead; i++) {
                    // Word counting logic (simple version, might miss words split exactly at buffer boundary)
                    char c = (char) buffer[i];
                     if (Character.isLetterOrDigit(c)) {
                        currentWord.append(c);
                    } else {
                        if (currentWord.toString().equals(WORD_TO_COUNT)) {
                            wordCount++;
                        }
                        currentWord.setLength(0); // Reset word
                    }
                    // Encryption
                    encryptedBuffer[i] = (byte) encryptByte(buffer[i]);
                }
                 // Check word at the end of buffer processing
                 if (currentWord.length() > 0 && !Character.isLetterOrDigit((char)buffer[bytesRead-1])) {
                      if (currentWord.toString().equals(WORD_TO_COUNT)) {
                            wordCount++;
                        }
                        currentWord.setLength(0);
                 }

                bos.write(encryptedBuffer, 0, bytesRead);
            }
             // Check if the last word in the file matches
            if (currentWord.toString().equals(WORD_TO_COUNT)) {
                 wordCount++;
            }

            return wordCount;
        } catch (IOException e) {
            System.err.println("Error during buffered byte stream copy: " + e.getMessage());
            return -1; // Indicate error
        }
    }

    private static int copyUsingBufferedCharacterStreams(String sourcePath, String destPath) {
        int wordCount = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(sourcePath), BUFFER_SIZE);
             BufferedWriter writer = new BufferedWriter(new FileWriter(destPath), BUFFER_SIZE)) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+|\\p{Punct}"); // Split by whitespace or punctuation
                for (String word : words) {
                    if (word.equals(WORD_TO_COUNT)) {
                        wordCount++;
                    }
                }
                // Encrypt and write line by line
                StringBuilder encryptedLine = new StringBuilder();
                 for (char c : line.toCharArray()) {
                    encryptedLine.append(encryptChar(c));
                }
                writer.write(encryptedLine.toString());
                writer.newLine();
            }
            return wordCount;
        } catch (IOException e) {
            System.err.println("Error during buffered character stream copy: " + e.getMessage());
            return -1; // Indicate error
        }
    }

     // Simple Caesar cipher encryption for bytes
    private static int encryptByte(int b) {
        char c = (char) b;
        if (Character.isLetter(c)) {
            char base = Character.isUpperCase(c) ? 'A' : 'a';
            return base + (c - base + ENCRYPTION_SHIFT) % 26;
        }
        return b; // Return non-letters unchanged
    }

     // Simple Caesar cipher encryption for characters
    private static char encryptChar(char c) {
        if (Character.isLetter(c)) {
            char base = Character.isUpperCase(c) ? 'A' : 'a';
            return (char) (base + (c - base + ENCRYPTION_SHIFT) % 26);
        }
        return c; // Return non-letters unchanged
    }
}
