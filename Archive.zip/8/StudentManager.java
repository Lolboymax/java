import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentManager {

    private static final String DATA_FILE = "IOExamples/students.dat";
    private static List<Student> studentList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        loadStudents(); // Load existing data on startup

        int choice;
        do {
            printMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    updateGpa();
                    break;
                case 3:
                    displayStudents();
                    break;
                case 4:
                    saveStudents(); // Save data before exiting
                    System.out.println("Exiting program. Student data saved.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);

        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n--- Student Record Manager ---");
        System.out.println("1. Add Student");
        System.out.println("2. Update Student GPA");
        System.out.println("3. Display All Students");
        System.out.println("4. Exit");
        System.out.println("----------------------------");
    }

    private static void addStudent() {
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine();
        // Basic check if student already exists
        if (findStudentById(id) != null) {
            System.out.println("Student with ID " + id + " already exists.");
            return;
        }
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Student GPA: ");
        double gpa = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        Student newStudent = new Student(id, name, gpa);
        studentList.add(newStudent);
        System.out.println("Student added successfully.");
        saveStudents(); // Save after adding
    }

    private static void updateGpa() {
        System.out.print("Enter Student ID to update GPA: ");
        String id = scanner.nextLine();
        Student student = findStudentById(id);

        if (student != null) {
            System.out.print("Enter new GPA for " + student.getName() + ": ");
            double newGpa = scanner.nextDouble();
            scanner.nextLine(); // Consume newline
            student.setGpa(newGpa);
            System.out.println("GPA updated successfully.");
            saveStudents(); // Save after updating
        } else {
            System.out.println("Student with ID " + id + " not found.");
        }
    }

    private static void displayStudents() {
        if (studentList.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }
        System.out.println("\n--- Student Records ---");
        for (Student student : studentList) {
            System.out.println(student);
        }
        System.out.println("-----------------------");
    }

    private static Student findStudentById(String id) {
        for (Student student : studentList) {
            if (student.getId().equalsIgnoreCase(id)) {
                return student;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked") // Suppress warning for cast from ObjectInputStream
    private static void loadStudents() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            Object obj = ois.readObject();
            if (obj instanceof List) {
                studentList = (List<Student>) obj;
                System.out.println("Student data loaded successfully from " + DATA_FILE);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Data file (" + DATA_FILE + ") not found. Starting with empty list.");
            studentList = new ArrayList<>(); // Ensure list is initialized if file doesn't exist
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading student data: " + e.getMessage());
            studentList = new ArrayList<>(); // Start fresh on error
        }
    }

    private static void saveStudents() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(studentList);
            // Optional: Add a confirmation message here if needed outside the exit case
        } catch (IOException e) {
            System.err.println("Error saving student data: " + e.getMessage());
        }
    }
}
