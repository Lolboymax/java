import java.util.Scanner;

public class NotBadReplace {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string:");
        String input = scanner.nextLine();

        int notIndex = input.indexOf("not");
        int badIndex = input.indexOf("bad");

        if (notIndex != -1 && badIndex != -1 && badIndex > notIndex) {
            String result = input.substring(0, notIndex) + "good" + input.substring(badIndex + 3);
            System.out.println("Modified string: " + result);
        } else {
            System.out.println("No change: " + input);
        }

        scanner.close();
    }
}
