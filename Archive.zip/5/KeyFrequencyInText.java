import java.util.Scanner;

public class KeyFrequencyInText {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the text:");
        String text = scanner.nextLine();

        System.out.println("Enter the key to search:");
        String key = scanner.nextLine();

        int count = 0;
        int index = 0;

        while ((index = text.indexOf(key, index)) != -1) {
            count++;
            index += key.length();
        }

        System.out.println("The key \"" + key + "\" occurred " + count + " times.");

        scanner.close();
    }
}
