package complex;

class Complex {
    double real, imag;

    Complex(double r, double i) {
        this.real = r;
        this.imag = i;
    }

    Complex add(Complex c) { // compile-time polymorphism (overloading)
        return new Complex(this.real + c.real, this.imag + c.imag);
    }

    Complex add(double r, double i) {
        return new Complex(this.real + r, this.imag + i);
    }

    void display() {
        System.out.println(real + " + " + imag + "i");
    }

    // Shallow copy
    Complex shallowCopy() {
        return this;
    }

    // Deep copy
    Complex deepCopy() {
        return new Complex(this.real, this.imag);
    }

    // Shallow clone
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    // Deep clone
    Complex deepClone() {
        return new Complex(this.real, this.imag);
    }

    @Override
    protected void finalize() throws Throwable {
        System.out.println("Complex object is garbage collected");
    }
}

// Single inheritance
class ComplexChild extends Complex {
    ComplexChild(double r, double i) {
        super(r, i);
    }

    @Override
    void display() { // runtime polymorphism
        System.out.println("ComplexChild: " + real + " + " + imag + "i");
    }
}

// Multilevel inheritance
class ComplexGrandChild extends ComplexChild {
    ComplexGrandChild(double r, double i) {
        super(r, i);
    }

    @Override
    void display() {
        System.out.println("ComplexGrandChild: " + real + " + " + imag + "i");
    }
}

// Hierarchical inheritance
class AnotherChild extends Complex {
    AnotherChild(double r, double i) {
        super(r, i);
    }
}

// Multiple inheritance via interfaces
interface Printable {
    void print();
}

interface Showable {
    void show();
}

class MultiInheritanceClass implements Printable, Showable {
    public void print() {
        System.out.println("Printable interface");
    }

    public void show() {
        System.out.println("Showable interface");
    }
}

public class ComplexDemo {
    public static void main(String[] args) {
        Complex c1 = new Complex(2, 3);
        Complex c2 = new Complex(4, 5);

        Complex sum = c1.add(c2);
        sum.display();

        Complex sum2 = c1.add(1, 1);
        sum2.display();

        ComplexChild cc = new ComplexChild(6, 7);
        cc.display();

        ComplexGrandChild cgc = new ComplexGrandChild(8, 9);
        cgc.display();

        AnotherChild ac = new AnotherChild(10, 11);
        ac.display();

        MultiInheritanceClass mic = new MultiInheritanceClass();
        mic.print();
        mic.show();

        Complex shallow = c1.shallowCopy();
        Complex deep = c1.deepCopy();

        Complex deepClone = c1.deepClone();

        System.gc(); // to invoke finalize
    }
}
