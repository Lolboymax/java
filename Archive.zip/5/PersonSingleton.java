public final class PersonSingleton {
    private static final PersonSingleton instance = new PersonSingleton("John Doe", 30);

    private final String name;
    private final int age;

    private PersonSingleton(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public static PersonSingleton getInstance() {
        return instance;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public static void main(String[] args) {
        PersonSingleton person = PersonSingleton.getInstance();
        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());
    }
}
