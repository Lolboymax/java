package com.example;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/calculate")
public class CalculatorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String HISTORY_COOKIE_NAME = "calculationHistoryCookie";
    private static final String HISTORY_SESSION_ATTR = "calculationHistory";
    private static final String HISTORY_DELIMITER = ";";
    private static final int COOKIE_MAX_AGE = 60 * 60 * 24 * 30; // 30 days

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String num1Str = request.getParameter("num1");
        String num2Str = request.getParameter("num2");
        String operation = request.getParameter("operation");

        double num1, num2;
        double result = 0;
        String error = null;
        String calculationString = null;

        // --- Input Validation ---
        try {
            num1 = Double.parseDouble(num1Str);
            num2 = Double.parseDouble(num2Str);
        } catch (NumberFormatException e) {
            error = "Invalid input: Please enter valid numbers.";
            request.setAttribute("error", error);
            request.getRequestDispatcher("index.jsp").forward(request, response);
            return;
        }

        // --- Perform Calculation ---
        switch (operation) {
            case "add":
                result = num1 + num2;
                calculationString = num1 + " + " + num2 + " = " + result;
                break;
            case "subtract":
                result = num1 - num2;
                calculationString = num1 + " - " + num2 + " = " + result;
                break;
            case "multiply":
                result = num1 * num2;
                calculationString = num1 + " * " + num2 + " = " + result;
                break;
            case "divide":
                if (num2 == 0) {
                    error = "Cannot divide by zero.";
                } else {
                    result = num1 / num2;
                    calculationString = num1 + " / " + num2 + " = " + result;
                }
                break;
            default:
                error = "Invalid operation selected.";
        }

        // --- Handle Errors ---
        if (error != null) {
            request.setAttribute("error", error);
            request.getRequestDispatcher("index.jsp").forward(request, response);
            return;
        }

        // --- Update Session History ---
        HttpSession session = request.getSession();
        @SuppressWarnings("unchecked")
        List<String> sessionHistory = (List<String>) session.getAttribute(HISTORY_SESSION_ATTR);
        if (sessionHistory == null) {
            sessionHistory = new ArrayList<>();
        }
        sessionHistory.add(calculationString);
        session.setAttribute(HISTORY_SESSION_ATTR, sessionHistory);

        // --- Update Cookie History ---
        String cookieHistoryStr = getCookieValue(request, HISTORY_COOKIE_NAME);
        if (cookieHistoryStr == null || cookieHistoryStr.isEmpty()) {
            cookieHistoryStr = calculationString;
        } else {
            // Append new calculation, ensuring not to exceed reasonable cookie limits if needed
            cookieHistoryStr += HISTORY_DELIMITER + calculationString;
        }
        setCookieValue(response, HISTORY_COOKIE_NAME, cookieHistoryStr, COOKIE_MAX_AGE);


        // --- Forward to Result Page ---
        request.setAttribute("result", result);
        // Session history is automatically available in the JSP via the session implicit object
        // Cookie history needs to be read again in the JSP (or passed as attribute if preferred)
        request.getRequestDispatcher("result.jsp").forward(request, response);
    }

    // Helper method to get cookie value
    private String getCookieValue(HttpServletRequest request, String cookieName) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookieName.equals(cookie.getName())) {
                    try {
                        return URLDecoder.decode(cookie.getValue(), "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                       // Should not happen with UTF-8
                       System.err.println("Error decoding cookie: " + e.getMessage());
                       return null;
                    }
                }
            }
        }
        return null;
    }

    // Helper method to set cookie value
    private void setCookieValue(HttpServletResponse response, String cookieName, String value, int maxAge) {
         try {
            String encodedValue = URLEncoder.encode(value, "UTF-8");
            Cookie cookie = new Cookie(cookieName, encodedValue);
            cookie.setMaxAge(maxAge); // Set cookie expiry time
            cookie.setPath("/"); // Make cookie available for the whole application
            response.addCookie(cookie);
        } catch (UnsupportedEncodingException e) {
             // Should not happen with UTF-8
             System.err.println("Error encoding cookie: " + e.getMessage());
        }
    }
}
