public class QueueDemo {
    int front, rear, capacity;
    int[] queue;

    public QueueDemo(int size) {
        capacity = size;
        front = rear = 0;
        queue = new int[capacity];
    }

    public void enqueue(int data) {
        if (rear == capacity) {
            System.out.println("Queue is full");
            return;
        }
        queue[rear] = data;
        rear++;
    }

    public void dequeue() {
        if (front == rear) {
            System.out.println("Queue is empty");
            return;
        }
        for (int i = 0; i < rear - 1; i++) {
            queue[i] = queue[i + 1];
        }
        rear--;
    }

    public void display() {
        if (front == rear) {
            System.out.println("Queue is empty");
            return;
        }
        for (int i = front; i < rear; i++) {
            System.out.print(queue[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        QueueDemo q = new QueueDemo(5);
        q.enqueue(10);
        q.enqueue(20);
        q.enqueue(30);
        q.display();

        q.dequeue();
        q.display();

        q.enqueue(40);
        q.enqueue(50);
        q.enqueue(60); // should show full
        q.display();
    }
}
